from django.shortcuts import render
import requests
from .forms import LocationForm

def get_weather_data(latitude, longitude):
    api_url = f'https://api.met.no/weatherapi/locationforecast/2.0/compact?lat={latitude}&lon={longitude}'
    headers = {'Content-Type': 'application/json', 'User-Agent': 'Mili weather app/1.0 (mmakwana@asu.edu)'}
    response = requests.get(api_url, headers=headers)
    
    if response.status_code == 200:
        return response.json()
    else:
        return None

def weather(request):
    if request.method == 'POST':
        form = LocationForm(request.POST)
        if form.is_valid():
            latitude = form.cleaned_data['latitude']
            longitude = form.cleaned_data['longitude']
            weather_data = get_weather_data(latitude, longitude)
            
            if weather_data:
                # Extract relevant information from weather_data and pass it to the template
                context = {
                    'latitude': latitude,
                    'longitude': longitude,
                    'weather_info': weather_data['properties']['timeseries'][0]['data']['instant']['details'],
                }
                return render(request, 'weatherapp/weather.html', context)
            else:
                error_message = 'Failed to fetch weather data. Please try again.'
        else:
            error_message = 'Invalid input. Please enter valid coordinates.'
    else:
        form = LocationForm()
        error_message = None

    context = {
        'form': form,
        'error_message': error_message,
    }
    return render(request, 'weatherapp/weather.html', context)
